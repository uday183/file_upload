
from django.urls import path,include
from file.views import file_save,login_page,signup_page

urlpatterns = [
	path('login/', login_page, name='login_page' ),
	path('signup/', signup_page, name='signup' ),
    path('uploads/', file_save, name='load_call' ),

    
]

