from django.shortcuts import render,redirect
from .forms import FileForm
from .models import UploadFiles
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
###########API##################################
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User
###########API##################################


def file_save(request):
	if request.method == 'POST':
		form = FileForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
		return redirect('/uploads')		
	else:
		form= FileForm()
		data = UploadFiles.objects.all()
		return render(request, 'upload.html', {
	        'form': form,'data':data,
	    })

def login_page(request):
	#import ipdb;ipdb.set_trace()
	if request.method == 'POST':
		form = AuthenticationForm(request=request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				return redirect('/uploads/')
	form = AuthenticationForm()
	return render(request = request,template_name = "login.html",context={"form":form})


def signup_page(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            usr = form.cleaned_data.get('username')
            pwd = form.cleaned_data.get('password1')
            user = authenticate(username=usr, password=pwd)
            login(request, user)
            return redirect('/login/')
    else:
        form = UserCreationForm()
    return render(request, 'sign_up.html', {'form': form})



class LoginApi(APIView):
	def post(self, request, format=None):
		#import ipdb;ipdb.set_trace()
		response_dict = {"status":True,"data":{}}
		username = request.data.get('username')
		password = request.data.get('password')
		user = authenticate(username=username, password=password)
		if user.is_active:
			login(request, user)
			return Response(response_dict)
		else:
			response_dict["status"]=False
			return Response(response_dict)


class SignUpApi(APIView):

	def post(self,request):	
		# import ipdb;ipdb.set_trace()
		response_dict = {"status":True,"data":{}}
		usr = request.data.get('username')
		pwd = request.data.get('password')
		email = request.data.get('email')
		first_name = request.data.get('first_name')
		last_name = request.data.get('last_name')
		try:
			user = User.objects.create(username=usr,email=email,first_name=first_name,last_name=last_name)
		except Exception as e:
			response_dict['data']=False
			return Response(response_dict)
		user.set_password(pwd)
		user.save()
		return Response(response_dict)
class UploadFilesList(APIView):
	def get(self,request):
		response_dict = {"status":True,"data":{}}
		upload_obj = UploadFiles.objects.all()
		if not upload_obj:
			response_dict['data']=False
			return Response(response_dict)
		l=[]
		http_protocol = 'http://'
		if request.is_secure():
			http_protocol = 'https://'
		host=http_protocol+request.META['HTTP_HOST']
		for each in upload_obj:
			d={}
			d['name'] = each.file.name
			d['docs'] = host+each.file.url
			l.append(d)
		response_dict['data']=l
		return Response(response_dict)






















