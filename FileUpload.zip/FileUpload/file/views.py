from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import FileForm
from django.http import JsonResponse
from .models import UploadFiles
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm


def file_save(request):
	if request.method == 'POST':
		form = FileForm(request.POST, request.FILES)
		if form.is_valid():
			form.save()
		return redirect('/main/uploads')		
	else:
		form= FileForm()
		data = UploadFiles.objects.all()
		return render(request, 'upload.html', {
	        'form': form,'data':data,
	    })

def login_page(request):
	#import ipdb;ipdb.set_trace()
	if request.method == 'POST':
		form = AuthenticationForm(request=request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				return redirect('/main/uploads/')
	form = AuthenticationForm()
	return render(request = request,template_name = "login.html",context={"form":form})


def signup_page(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/main/login/')
    else:
        form = UserCreationForm()
    return render(request, 'sign_up.html', {'form': form})




























