from django.contrib import admin
from file.models import UploadFiles
# Register your models here.

admin.site.register(UploadFiles)