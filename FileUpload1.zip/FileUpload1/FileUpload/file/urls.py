
from django.urls import path,include
from file.views import file_save,login_page,signup_page,LoginApi,UploadFilesList,SignUpApi

urlpatterns = [
	path('', login_page, name='login_page' ),
	path('signup/', signup_page, name='signup' ),
    path('uploads/', file_save, name='load_call' ),
    path('login_api/', LoginApi.as_view(), name='login_api' ),
    path('sign_api/', SignUpApi.as_view(), name='SignUpApi' ),
    path('upload_list_api/', UploadFilesList.as_view(), name='UploadFilesList' ),
    
]

